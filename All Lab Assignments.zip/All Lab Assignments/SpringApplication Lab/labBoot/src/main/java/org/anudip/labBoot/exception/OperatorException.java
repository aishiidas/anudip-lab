package org.anudip.labBoot.exception;

public class OperatorException extends RuntimeException {

}
