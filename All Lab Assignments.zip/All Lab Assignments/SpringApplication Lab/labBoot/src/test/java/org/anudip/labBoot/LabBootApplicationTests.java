package org.anudip.labBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
