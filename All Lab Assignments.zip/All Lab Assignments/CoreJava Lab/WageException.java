package org.anudip.lab;

public class WageException extends RuntimeException {
	public WageException(String message) {
        super(message);
    }

}
