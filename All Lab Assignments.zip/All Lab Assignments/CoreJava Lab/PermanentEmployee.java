package org.anudip.lab;

public class PermanentEmployee extends Employee {
    private double monthlySalary;
    private double pf; // 15% of monthlySalary
    private double tax;
    private static int idGen = 1000; // Initialize idGen for permanent employees
 // Constructor for PermanentEmployee class
    public PermanentEmployee(String employeeName, String department, double monthlySalary) {
    	// Call the constructor of the superclass (Employee)
        super(employeeName, department);
     // Initialize instance variables
        this.monthlySalary = monthlySalary;
        this.pf = 0.15 * monthlySalary;
     // Generate and set the employee ID
        this.setEmployeeId(generateId());
     // Calculate tax for the employee
        calculateTax();
    }
 // Getter for monthlySalary
    public double getMonthlySalary() {
        return monthlySalary;
    }
 // Getter for pf
    public double getPf() {
        return pf;
    }
 // Getter for tax
    public double getTax() {
        return tax;
    }
 // Override the calculateTax() method to calculate tax for a permanent employee
    @Override
    public void calculateTax() {
        double annualSalary = monthlySalary * 12;
        this.tax = 0.1 * annualSalary;
    }
 // Override the toString() method to format permanent employee information
    @Override
    public String toString() {
        return String.format("%-10s %-20s %-15s %-10.2f %-10.2f %-10.2f",
                             getEmployeeId(), getEmployeeName(), getDepartment(),
                             monthlySalary, pf, tax);
    }
 // Static method to generate employee ID
    public static String generateId() {
        return "P" + idGen++;
    }
}//end of class
