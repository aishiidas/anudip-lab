package org.anudip.lab;
import java.util.Scanner;
public class MailCreater {
	public static String createMailAccount(String studentName) {
        // Convert the student name to lowercase
        String lowercaseName = studentName.toLowerCase();
        // Replace spaces with dots
        String formattedName = lowercaseName.replace(" ", ".");
        // Append the domain and return the mail id
        return formattedName + "@tsr.edu";
    }
	public static void main(String[] args) {
		 // Create a Scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);
        // Prompt the user to enter the student name
        System.out.print("Enter the student name: ");
        String studentName = scanner.nextLine();
        // Invoke the createMailAccount method to create the mail id
        String mailId = createMailAccount(studentName);
        // Display the student's mail id
        System.out.println("Student's mail id: " + mailId);
        }//end of main
}//end of class