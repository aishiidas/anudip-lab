package org.anudip.lab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain {
    public static void main(String[] args) {
    	Employee emp;
        Scanner scanner = new Scanner(System.in);
     // Prompt for the number of employees
        System.out.println("Enter Number of Employees:");
        int numEmployees = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        List<Employee> employees = new ArrayList<>();
     // Prompt for and collect employee details
        System.out.println("Enter all Employees details...");
        for (int i = 0; i < numEmployees; i++) {
            String input = scanner.nextLine();
            String[] data = input.split(",");

            if (data.length >= 3) {
                String name = data[0].trim();
                String department = data[1].trim();

                if (data.length == 3) { // Permanent Employee
                    double monthlySalary = Double.parseDouble(data[2].trim());
                    emp = new PermanentEmployee(name, department, monthlySalary);
                    employees.add(emp);
                } else if (data.length == 4) { // Contract Employee
                    int contractPeriod = Integer.parseInt(data[2].trim());
                    double contractAmount = Double.parseDouble(data[3].trim());
                    emp = new ContractEmployee(name, department, contractPeriod, contractAmount);
                    employees.add(emp);
                }
            }
        }

        // Sort the employees list
        Collections.sort(employees);

        // Display permanent employees
        System.out.println("\nPermanent Employee List\n");
        System.out.printf("%-10s %-20s %-15s %-10s %-10s %-10s%n", "Id", "Name", "Department", "Salary", "PF", "Tax");
        for (Employee employee : employees) {
            if (employee instanceof PermanentEmployee) {
                System.out.println(employee);
            }
        }

        // Display contract employees
        System.out.println("\nContract Employee List\n");
        System.out.printf("%-10s %-20s %-15s %-10s %-10s %-10s%n", "Id", "Name", "Department", "Period", "Amount", "Tax");
        for (int i = employees.size() - 1; i >= 0; i--) {
            Employee employee = employees.get(i);
            if (employee instanceof ContractEmployee) {
                System.out.println(employee);
            }
        }
    }//end of main
}//end class
