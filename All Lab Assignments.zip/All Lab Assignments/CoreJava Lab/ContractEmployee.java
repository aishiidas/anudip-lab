package org.anudip.lab;

public class ContractEmployee extends Employee {
    private int contractPeriod;
    private double contractAmount;
    private double tax;
    private static int idGenerator = 2000; // Initialize idGenerator for contract employees
 // Constructor for ContractEmployee class
    public ContractEmployee(String employeeName, String department, int contractPeriod, double contractAmount) {
    	// Call the constructor of the superclass (Employee)
        super(employeeName, department);
     // Initialize instance variables
        this.contractPeriod = contractPeriod;
        this.contractAmount = contractAmount;
     // Generate and set the employee ID
        this.setEmployeeId(generateId());
     // Calculate tax for the contract employee
        calculateTax();
    }
 // Getter for contractPeriod
    public int getContractPeriod() {
        return contractPeriod;
    }
 // Getter for contractAmount
    public double getContractAmount() {
        return contractAmount;
    }
 // Getter for tax
    public double getTax() {
        return tax;
    }
 // Override the calculateTax() method to calculate tax for a contract employee
    @Override
    public void calculateTax() {
        this.tax = (contractAmount/contractPeriod)*0.10;
    }
 // Override the toString() method to format contract employee information
    @Override
    public String toString() {
        return String.format("%-10s %-20s %-15s %-10d %-10.2f %-10.2f",
                             getEmployeeId(), getEmployeeName(), getDepartment(),
                             contractPeriod, contractAmount, tax);
    }
 // Static method to generate employee ID
    public static String generateId() {
        return "C" + idGenerator++;
    }
}//end of class
