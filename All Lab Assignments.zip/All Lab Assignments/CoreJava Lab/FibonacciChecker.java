package org.anudip.lab;
import java.util.Scanner;
public class FibonacciChecker {
	public static String checkFibonacci(int n) {
        int a = 0;
        int b = 1;
        // Special case: n is 0 or 1
        if (n == 0 || n == 1) {
            return "yes";
        }
        // Generate Fibonacci sequence until reaching n or exceeding it
        while (b < n) {
            int temp = b;
            b = a + b;
            a = temp;
        }
        // Check if n is equal to the current Fibonacci number
        if (b == n) {
            return "yes";
        } else {
            return "no";
        }
    }
	public static void main(String[] args) {
		// Create a Scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the number
        System.out.print("Enter a number: ");
        int number = scanner.nextInt();

        // Check if the number is part of the Fibonacci sequence
        String result = checkFibonacci(number);

        // Display the result
        System.out.println(result);
	}//end of main
}//end of class
