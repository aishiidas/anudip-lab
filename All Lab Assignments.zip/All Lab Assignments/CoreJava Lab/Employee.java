package org.anudip.lab;

public abstract class Employee implements Comparable<Employee> {
    private String employeeId;
    private String employeeName;
    private String department;
 // Constructor that takes employeeName and department as parameters
    public Employee(String employeeName, String department) {
        this.employeeName = employeeName;
        this.department = department;
    }
 // Getter for employeeId
    public String getEmployeeId() {
        return employeeId;
    }
 // Setter for employeeId
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
 // Getter for employeeName
    public String getEmployeeName() {
        return employeeName;
    }
 // Getter for department
    public String getDepartment() {
        return department;
    }
 // Abstract method to calculate tax (needs to be implemented by subclasses)
    public abstract void calculateTax();
 // Override toString() method to format employee information
    @Override
    public String toString() {
        return String.format("%-10s %-20s %-15s", employeeId, employeeName, department);
    }
    // Implement the compareTo() method from the Comparable interface
    // to compare employees based on their employeeId
    @Override
    public int compareTo(Employee other) {
        return this.employeeId.compareTo(other.employeeId);
    }
}//end of class
