package org.anudip.lab;
import java.io.*;
import java.util.Scanner;

public class ResultMain {
    private static StudentResult[] allStudents;
    private static final String FILE_PATH = "f:/StudentResult.txt";

    private static int getNumberOfStudents() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH));
        int numberOfStudents = 0;

        while (reader.readLine() != null) {
            numberOfStudents++;
        }

        reader.close();
        return numberOfStudents;
    }

    private static void convertToList(int numberOfStudents) throws IOException {
        allStudents = new StudentResult[numberOfStudents];
        BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH));

        String line;
        int index = 0;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("-");
            if (parts.length >= 3) {
                allStudents[index] = new StudentResult(parts[0], parts[1], Double.parseDouble(parts[2]));
                index++;
            }
        }

        reader.close();
    }
    public static void main(String[] args) {
        try {
            int numberOfStudents = getNumberOfStudents();
            convertToList(numberOfStudents);

            Scanner scanner = new Scanner(System.in);

            boolean continueEnteringMarks = true;
            while (continueEnteringMarks) {
                System.out.print("Hello User! Please Enter the Roll Number you want to Edit (or enter 'Exit' to stop): ");
                String input = scanner.nextLine();

                if (input.equalsIgnoreCase("exit")) {
                    continueEnteringMarks = false;
                } else {
                    StudentResult selectedStudent = null;
                    boolean found = false;
                    for (StudentResult student : allStudents) {
                        if (student != null && student.getRollNumber().equals(input)) {
                            selectedStudent = student;
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        System.out.println("Oh no! Student with Roll Number " + input + " doesn't exist in our Database.");
                    } else {
                        System.out.print("Enter Marks for English: ");
                        double englishMarks = scanner.nextDouble();
                        System.out.print("Enter Marks for Language: ");
                        double languageMarks = scanner.nextDouble();
                        System.out.print("Enter Marks for Mathematics: ");
                        double mathMarks = scanner.nextDouble();
                        System.out.print("Enter Marks for Science: ");
                        double scienceMarks = scanner.nextDouble();
                        System.out.print("Enter Marks for Social Study: ");
                        double socialStudyMarks = scanner.nextDouble();

                        double annualTotal = englishMarks + languageMarks + mathMarks + scienceMarks + socialStudyMarks;
                        selectedStudent.setAnnualTotal(annualTotal);
                        selectedStudent.setGrade(ResultService.gradeCalculation(selectedStudent));

                        updateFile(); // Call the method to update the file

                        System.out.println("Congrats! Student Record is successfully Updated:\n" + selectedStudent);
                    }

                    scanner.nextLine(); // Consume the newline character after reading double input
                }
            }

            System.out.println("Exiting Program.");
            scanner.close(); // Close the scanner after the loop is finished
        } catch (IOException e) {
            System.err.println("Error Reading or Writing to file: " + e.getMessage());
        } catch (StudentNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void updateFile() throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH));
        for (StudentResult student : allStudents) {
            if (student != null) {
                double annualTotal = student.getAnnualTotal(); // Get the updated annual total
                writer.println(student.getRollNumber() + "-" +
                        student.getStudentName() + "-" +
                        student.getHalfYearlyTotal() + "-" +
                        String.format("%.2f", annualTotal) + "-" + // Format to two decimal points
                        student.getGrade());
            }
        }
        writer.close();
    }//end of main
}//end of class