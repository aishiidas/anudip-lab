package org.anudip.hibernateLab.bean;

import javax.persistence.*;

@Entity
@Table(name = "result")
public class Result {
    @Id
    @Column(name = "roll_number") // Map this field to the "roll_number" column in the database
    private String rollNumber;

    @Column(name = "half_yearly_total") // Map this field to the "half_yearly_total" column in the database
    private Double halfYearlyTotal;

    @Column(name = "annual_total") // Map this field to the "annual_total" column in the database
    private Double annualTotal;

    @Column(name = "grade") // Map this field to the "grade" column in the database
    private String grade;

    // Constructors
    public Result() {
        // Default constructor required by Hibernate
    }

 // Parameterized constructor to initialize the Result object with relevant attributes.
    public Result(String rollNumber, Double halfYearlyTotal, Double annualTotal) {
        this.rollNumber = rollNumber;
        this.halfYearlyTotal = halfYearlyTotal;
        this.annualTotal = annualTotal;
        this.grade = gradeCalculation(annualTotal + halfYearlyTotal);
    }

    // Getter method for rollNumber
    public String getRollNumber() {
        return rollNumber;
    }

    // Setter method for rollNumber
    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    // Getter method for halfYearlyTotal
    public Double getHalfYearlyTotal() {
        return halfYearlyTotal;
    }

    // Setter method for halfYearlyTotal
    public void setHalfYearlyTotal(Double halfYearlyTotal) {
        this.halfYearlyTotal = halfYearlyTotal;
    }

    // Getter method for annualTotal
    public Double getAnnualTotal() {
        return annualTotal;
    }

    // Setter method for annualTotal
    public void setAnnualTotal(Double annualTotal) {
        this.annualTotal = annualTotal;
    }

    public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
    public String toString() {
        return String.format("%-5s %-20s %-20s  %-5s", rollNumber, halfYearlyTotal, annualTotal, grade);
    }

 // Private method for calculating the grade based on total marks
    private String gradeCalculation(double totalMarks) {
        if (totalMarks >= 90) {
            return "E";
        } else if (totalMarks >= 75) {
            return "V";
        } else if (totalMarks >= 60) {
            return "G";
        } else if (totalMarks >= 45) {
            return "P";
        } else {
            return "F";
        }
    }
}//end of class
