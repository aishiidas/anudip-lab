package org.anudip.hibernateLab.bean;
//Custom exception class for price-related exceptions
public class PriceException extends RuntimeException {
	
	  // Constructor for PriceException class that accepts a message
    public PriceException(String message) {
    	
    	// Call the constructor of the parent class (RuntimeException) with the provided message
        super(message);
    }
}
