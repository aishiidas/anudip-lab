package org.anudip.hibernateLab.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.anudip.hibernateLab.bean.Result;
import org.anudip.hibernateLab.bean.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DatabaseHandler2 {
    private static final DatabaseHandler2 dbHandler2 = new DatabaseHandler2();
    private static SessionFactory sessionFactory;

    private DatabaseHandler2() {
        try {
            // Load Hibernate properties from hibernate.properties
            Properties properties = new Properties();
            InputStream hibernatePropsStream = getClass().getClassLoader().getResourceAsStream("hibernate.properties");
            if (hibernatePropsStream != null) {
                properties.load(hibernatePropsStream);
            } else {
                throw new IOException("Unable to load hibernate.properties");
            }

            // Create a Hibernate configuration
            Configuration config = new Configuration();
            config.setProperties(properties);
            config.addAnnotatedClass(Student.class);// Mention your entity class
            config.addAnnotatedClass(Result.class);
            // Build the SessionFactory
            sessionFactory = config.buildSessionFactory();
        } catch (IOException e) {
            // Handle or log the exception
            e.printStackTrace();
            throw new RuntimeException("Error initializing Hibernate configuration.");
        }
    }

    // Get the single instance of DatabaseHandler
    public static DatabaseHandler2 getDatabaseHandler2() {
        return dbHandler2;
    }

    // Create a Hibernate session
    public Session createSession() {
        if (sessionFactory == null) {
            throw new RuntimeException("Session factory is not initialized.");
        }
        return sessionFactory.openSession();
    }

    // Close a Hibernate session
    public void closeSession(Session session) {
        if (session != null && session.isOpen()) {
            session.close();
        }
    }

    // Close the SessionFactory
    public void closeSessionFactory() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }
}//end of class
