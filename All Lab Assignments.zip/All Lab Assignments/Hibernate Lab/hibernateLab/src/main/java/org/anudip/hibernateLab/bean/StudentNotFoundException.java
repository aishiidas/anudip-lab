package org.anudip.hibernateLab.bean;

public class StudentNotFoundException extends RuntimeException {
    public StudentNotFoundException(String message) {
        super(message);
    }
}//end of class
