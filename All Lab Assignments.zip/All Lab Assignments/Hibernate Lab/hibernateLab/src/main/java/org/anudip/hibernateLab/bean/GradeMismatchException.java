package org.anudip.hibernateLab.bean;

//Custom exception class for grade mismatch exceptions
public class GradeMismatchException extends RuntimeException {
	
	// Constructor for GradeMismatchException class that accepts a message
    public GradeMismatchException(String message) {
    	
    	// Call the constructor of the parent class (RuntimeException) with the provided message
        super(message);
    }
}
